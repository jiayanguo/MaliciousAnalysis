package com.dexteroid.db.util;

import java.sql.*;

public class DBInfo {
	private static final String driver = "com.mysql.jdbc.Driver";
	private static final String url = "jdbc:mysql://localhost:3306/dexteroid";
	private static final String uid = "root";
	private static final String psd ="gjy";
	private static Connection instance = null;
	
	public static Connection getInstance(){
		
		if(instance==null){
			try{
				Class.forName(driver);
				instance=DriverManager.getConnection(url,uid,psd);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		return instance;
	}
}
