package com.dexteroid.db.cmd;

public abstract class DBCmd {

	Object result;
	
	public abstract void execute();
	
	public void setResult(Object result) {
		this.result = result;
	}
	
	public Object getResult(){
		return result;
	}
}
