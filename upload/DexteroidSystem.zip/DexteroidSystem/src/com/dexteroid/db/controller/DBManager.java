package com.dexteroid.db.controller;

import com.dexteroid.db.impl.MySQL_RDBImpl;
import com.dexteroid.db.interfaces.DBImplInterface;

public class DBManager {
	
	DBImplInterface imp = new MySQL_RDBImpl();
	
	public String getFinalResult(String fileName) {
		String finalResult = imp.getFinalResult(fileName);
		return finalResult;
	}

	public void saveFinalResult(String fileName, String finalResult) {
		imp.saveFinalResult(fileName, finalResult);
	}
	
	public boolean login(String userName, String password){
		boolean isUser = imp.login(userName, password);
		return isUser;
	}
	
}
