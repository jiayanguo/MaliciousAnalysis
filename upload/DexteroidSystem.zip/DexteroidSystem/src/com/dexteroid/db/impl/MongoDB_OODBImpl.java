package com.dexteroid.db.impl;

import com.dexteroid.db.cmdimpl.ConnectDB;
import com.dexteroid.db.cmdimpl.DisconnectDB;
import com.dexteroid.db.cmdimpl.GetFinalResult;
import com.dexteroid.db.cmdimpl.Login;
import com.dexteroid.db.cmdimpl.SaveFinalResult;
import com.dexteroid.db.interfaces.DBImplInterface;

public class MongoDB_OODBImpl implements DBImplInterface{

	@Override
	public String getFinalResult(String fileName) {
		GetFinalResult getFinalResult = new GetFinalResult(fileName);
		getFinalResult.execute();
		return (String) getFinalResult.getResult();
	}

	@Override
	public void saveFinalResult(String fileName, String finalResult) {
		SaveFinalResult saveFinalResult = new SaveFinalResult(fileName, finalResult);
		saveFinalResult.execute();
	}

	@Override
	public void connectDB() {
		ConnectDB connectDB = new ConnectDB();
		connectDB.execute();
	}

	@Override
	public void disconnectDB() {
		DisconnectDB disconnectDB = new DisconnectDB();
		disconnectDB.execute();
	}

	@Override
	public boolean login(String userName, String password) {
		Login login = new Login(userName, password);
		login.execute();
		return (boolean) login.getResult();
	}
	
}
