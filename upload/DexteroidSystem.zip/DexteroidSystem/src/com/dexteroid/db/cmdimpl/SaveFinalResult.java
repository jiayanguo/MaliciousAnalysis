package com.dexteroid.db.cmdimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.dexteroid.db.cmd.DBCmd;
import com.dexteroid.db.util.DBInfo;


public class SaveFinalResult extends DBCmd{
	String fileName;
	String finalResult;
	public SaveFinalResult(String fileName, String finalResult){
		super();
		this.fileName = fileName;
		this.finalResult = finalResult;
	}
	
	@Override
	public void execute() {
		/*save finalResult to database*/
		Connection conn = DBInfo.getInstance();
		String sql="insert into resulttable(filename,finalresult) values (?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,fileName);
			ps.setString(2,finalResult);
			ps.executeUpdate();
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
