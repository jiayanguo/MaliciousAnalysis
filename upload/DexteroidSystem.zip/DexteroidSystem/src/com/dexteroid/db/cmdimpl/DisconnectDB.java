package com.dexteroid.db.cmdimpl;

import java.sql.SQLException;

import com.dexteroid.db.cmd.DBCmd;
import com.dexteroid.db.util.DBInfo;

public class DisconnectDB extends DBCmd{

	@Override
	public void execute(){
		try {
			DBInfo.getInstance().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}	
}
