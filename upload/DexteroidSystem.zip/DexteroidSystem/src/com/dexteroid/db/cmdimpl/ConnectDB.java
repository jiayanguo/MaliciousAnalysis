package com.dexteroid.db.cmdimpl;

import com.dexteroid.db.cmd.DBCmd;
import com.dexteroid.db.util.DBInfo;

public class ConnectDB extends DBCmd{

	@Override
	public void execute() {
		DBInfo.getInstance();
	}
}
