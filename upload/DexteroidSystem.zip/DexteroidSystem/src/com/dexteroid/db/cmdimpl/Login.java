package com.dexteroid.db.cmdimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.dexteroid.db.cmd.DBCmd;
import com.dexteroid.db.util.DBInfo;

public class Login extends DBCmd{

	String userName;
	String password;
	public Login(String userName, String password){
		super();
		this.userName = userName;
		this.password = password;
	}
	
	@Override
	public void execute() {
		/*get finalResult from database*/
		Boolean isUser= false;
		Connection conn = DBInfo.getInstance();
		String sql="select * from user where username='"+userName+"'and password='"+password+"'";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				isUser = true;
			}
			rs.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.setResult(isUser);
	}
}
