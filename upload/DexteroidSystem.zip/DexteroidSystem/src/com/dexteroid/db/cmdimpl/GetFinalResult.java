package com.dexteroid.db.cmdimpl;

import java.sql.*;

import com.dexteroid.db.cmd.DBCmd;
import com.dexteroid.db.util.DBInfo;

public class GetFinalResult extends DBCmd {

	String fileName;
	public GetFinalResult(String fileName){
		super();
		this.fileName = fileName;
	}
	@Override
	public void execute() {
		/*get finalResult from database*/
		String finalResult= null;
		Connection conn = DBInfo.getInstance();
		String sql="select finalresult from resulttable where filename ="+fileName;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				finalResult = rs.getString("finalresult");
			}
			rs.close();
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.setResult(finalResult);
	}
}
