package com.dexteroid.db.interfaces;

public interface DBImplInterface {
	
	public String getFinalResult(String filename);
	public void saveFinalResult(String filename, String finalresult);
	public void connectDB();
	public void disconnectDB();
	public boolean login(String username,String password);

}
