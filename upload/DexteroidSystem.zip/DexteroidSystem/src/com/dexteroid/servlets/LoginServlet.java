package com.dexteroid.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.dexteroid.db.controller.DBManager;
import com.dexteroid.entity.User;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1425696479111887080L;

	public LoginServlet() {
		super();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
        HttpSession session=request.getSession();
        DBManager dbm=new DBManager();
        User user=new User();
        
		if(username==null||password==null||username.equals("")||password.equals("")){
			response.sendRedirect("login.jsp");
			return;
		}else{
			user.setUsername(username);
			user.setPassword(password);
			boolean isUser=dbm.login(username,password);
			if(isUser){
				session.setAttribute("username", username);
				if (username =="admin"||username.equals("admin")) {
					response.sendRedirect("upload.jsp");
					return;
				} else {
					response.sendRedirect("upload.jsp");
					return;
				}
			}else{
				response.sendRedirect("login.jsp");
				return;
			}
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

}
