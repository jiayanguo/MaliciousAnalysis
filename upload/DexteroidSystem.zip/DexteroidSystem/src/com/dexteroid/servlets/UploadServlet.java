package com.dexteroid.servlets;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.util.Streams;

import com.dexteroid.controller.AnalysisController;

public class UploadServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet { 
	 
	File tempDir = null;
	File saveDir = null;
	String fileName = null;
	public UploadServlet() {
		super();
	}     
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {    
		doPost(request,response);   
	}   
	public void init() throws ServletException {
		super.init();   
		String tempPath = "MaliciousAppsTemp";
		String savePath = "D:\\MaliciousAPPAnal\\";
   
		tempDir = new File(tempPath);  
		saveDir = new File(savePath); 
		
		if(!tempDir.isDirectory())     
			tempDir.mkdir();   
		if(!saveDir.isDirectory())    
			saveDir.mkdir();      
	}  
 
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {    
   try{   
        if(ServletFileUpload.isMultipartContent(request)){
		     DiskFileItemFactory dff = new DiskFileItemFactory();
		     dff.setRepository(tempDir);
		     dff.setSizeThreshold(1024000);//byte
		     
		     ServletFileUpload sfu = new ServletFileUpload(dff); 
		     sfu.setFileSizeMax(5000000);
		     sfu.setSizeMax(10000000);
		     
		     FileItemIterator fii = sfu.getItemIterator(request);
		     while(fii.hasNext()){ 
		    	 FileItemStream fis = fii.next();
			     if(!fis.isFormField() && fis.getName().length()>0){
				       
				       fileName = fis.getName().substring(fis.getName().lastIndexOf("\\")+1);
				       BufferedInputStream in = new BufferedInputStream(fis.openStream());
				       BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(saveDir+"\\"+fileName)));
				       Streams.copy(in, out, true);
			     }
		     }
		     HttpSession session=request.getSession();
		     session.setAttribute("filename", fileName);
		     
		     //deal with apk file
		     AnalysisController controller = new AnalysisController();
		     
		     
		     
		     
		     String result1 = "11111111111111111122222222";
		     String result2 = "22222222222222222233333333";
		     String result3 = "3333333333333333334444444";
		     String result4 = "4444444444444444555555555";
		     String result5 = "4444444444444444555555555";
		     
		     result5 = controller.getTaintResult();
		     
		     //set results to session
		     session.setAttribute("result1", result1);
		     session.setAttribute("result2", result2);
		     session.setAttribute("result3", result3);
		     session.setAttribute("result4", result4);
		     session.setAttribute("result5", result5);
		     
		     request.setAttribute("result5", result5);
		     
		     response.sendRedirect("result.jsp");  
	    }
   }catch(Exception e){        
	   e.printStackTrace(); 
   }
  }
}
