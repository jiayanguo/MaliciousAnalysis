package com.dexteroid.controller;

import com.dexteroid.db.controller.DBManager;
import com.uta.dexteroid.TaintAnalyzer.TaintAnalyzer;
import com.uta.dexteroid.cfg.CFGGenerator;

public class AnalysisController {
	String filename = "";
	String finalResult = "";
	public String getTaintResult(){
		String finalResult="";
		
		CFGGenerator cfg=new CFGGenerator("TestMaliciousApp.apk");
		TaintAnalyzer ta = new TaintAnalyzer();
		ta.analysis();
		System.out.println("\n\n\nTaint Analysis result");
		System.out.println(ta.getResult());
		
		finalResult=ta.getResult().toString();
		return finalResult;
	}

	public void useDatabase(){
		DBManager dbm = new DBManager();
		dbm.saveFinalResult(filename,finalResult);
		
	}
	
	public static void main(String[] args) {
//		DBManager dbm = new DBManager();
//		dbm.saveFinalResult("TestMaliciousApp","abcdefg");
		
		CFGGenerator cfg=new CFGGenerator("TestMaliciousApp.apk");
		TaintAnalyzer ta = new TaintAnalyzer();
		ta.analysis();
		System.out.println("\n\n\nTaint Analysis result");
		System.out.println(ta.getResult());
	}
	
	
}
