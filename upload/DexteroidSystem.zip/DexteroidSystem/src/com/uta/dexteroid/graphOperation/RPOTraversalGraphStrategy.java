package com.uta.dexteroid.graphOperation;

import java.util.ArrayList;
import java.util.List;

import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graph.Vertex;

public class RPOTraversalGraphStrategy implements GraphOperationStrategy{
	public List traversalOrderList=new ArrayList();
	public Graph graph;
	public RPOTraversalGraphStrategy(Graph graph){
		this.graph=graph;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		for (int i = 0; i <graph.getVertexQuan(); i++) {
			graph.vertexList.get(i).setColor(Vertex.WHITE);
		}
		graphAlg();
		reverse(traversalOrderList);
	}
	
	public void graphAlg(){
		System.out.println("Graph traversal order:");
		for (int i = 0; i < graph.getVertexQuan(); i++) {
			if (graph.vertexList.get(i).getColor()==Vertex.WHITE) {
				dfs_visit(graph.vertexList.get(i));
			}
		}
		//System.out.println("END");
	}
	
	private void dfs_visit(Vertex vertex) {
		// TODO Auto-generated method stub
		//traversalOrderList.add(vertex);
		//System.out.print(vertex.getName()+"--->");
		vertex.setColor(Vertex.GRAY);
		int index=graph.getVertexIndex(vertex);
		for (int i = 0; i < graph.getVertexQuan(); i++) {
			if (graph.edges.adjMatrix[index][i]==1) {
				Vertex succ=graph.getVertexByIndex(i);
				if (succ.getColor()==Vertex.WHITE) {				
					dfs_visit(succ);
				}
			}
		}
		traversalOrderList.add(vertex);
		vertex.setColor(Vertex.BLACK);
	}
	
	private List reverse(List list){
		List reverseList=new ArrayList<>();
		for (int i=list.size()-1; i>=0; i--) {
			reverseList.add(list.get(i));
			System.out.print(((Vertex) list.get(i)).getName()+"--->");
		}
		System.out.println("END");
		return reverseList;
	}

}
