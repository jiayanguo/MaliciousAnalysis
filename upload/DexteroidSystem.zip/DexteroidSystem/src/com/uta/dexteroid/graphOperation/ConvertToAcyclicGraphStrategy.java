package com.uta.dexteroid.graphOperation;

import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graph.Vertex;

public class ConvertToAcyclicGraphStrategy implements GraphOperationStrategy{

	public Graph graph;
	public ConvertToAcyclicGraphStrategy(Graph graph){
		this.graph=graph;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		for (int i = 0; i <graph.getVertexQuan(); i++) {
			graph.vertexList.get(i).setColor(Vertex.WHITE);
		}
		graphAlg();
	}
	
	public void graphAlg(){
		for (int i = 0; i < graph.getVertexQuan(); i++) {
			if (graph.vertexList.get(i).getColor()==Vertex.WHITE) {
				dfs_visit(graph.vertexList.get(i));
			}
		}
	}
	
	private void dfs_visit(Vertex vertex) {
		// TODO Auto-generated method stub
		
		vertex.setColor(Vertex.GRAY);
		int index=graph.getVertexIndex(vertex);
		for (int i = 0; i < graph.getVertexQuan(); i++) {
			if (graph.edges.adjMatrix[index][i]==1) {
				Vertex succ=graph.getVertexByIndex(i);
				if (succ.getColor()==Vertex.WHITE) {				
					dfs_visit(succ);
				}
				if(succ.getColor()==Vertex.GRAY){
					System.out.println("Found back edge!\nDelete back edge:"+index+"----->"+i);
					graph.edges.adjMatrix[index][i]=-1;
				}
			}
		}
		vertex.setColor(Vertex.BLACK);
	}

}
