package com.uta.dexteroid.graphOperation;

public interface GraphOperationStrategy{
	public void execute();
}
