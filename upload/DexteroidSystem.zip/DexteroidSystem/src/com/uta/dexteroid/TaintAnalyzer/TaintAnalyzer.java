package com.uta.dexteroid.TaintAnalyzer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.uta.dexteroid.cfg.AndroGuard;

public class TaintAnalyzer {
	private String filePath;  // read file path
	public StringBuffer result=new StringBuffer();
	
	private Map<String,List<String>> sourceSinkOrderMap = new HashMap<String,List<String>>();
	private String[] Scenario_1 = {"onCreate","onStart","onResume","*"} ;
	private String[] Scenario_2 = {"*","onPause","onResume","*"};
	private String[] Scenario_3 = {"*","onPause","onStop","onRestart","onStart","onResume","*"};
	private String[] Scenario_4 = {"*","onPause","onStop","onCreate","onStart","onResume","*"};
	private String[] Scenario_5 = {"*","onPause","onStop","onDestroy","onCreate","onStart","onResume","*"};
	private String[] callBackFunctions={"onBtnClicked","onConfigurationChanged","onLowMemory()"};
	
	public TaintAnalyzer(){
		this.filePath=AndroGuard.OUTPUTFP+"IepCFGgeneratorResult.txt";
	}
	public List<String> getSourceApi(){
		List<String> sourceApiList = new ArrayList<String>();
		sourceApiList.add("android.telephony.TelephonyManager: java.lang.String getDeviceId()");
		sourceApiList.add("com.android.internal.telephony.cdma.CDMAPhone: java.lang.String getDeviceId()");
		sourceApiList.add("com.android.internal.telephony.IccRecords: java.lang.String getVoiceMailNumber()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhone: java.lang.String getVoiceMailNumber()");
		sourceApiList.add("com.android.internal.telephony.cdma.CDMAPhone: java.lang.String getVoiceMailNumber()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhoneBase: java.lang.String getIccSerialNumber()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhone: java.lang.String getVoiceMailAlphaTag()");
		sourceApiList.add("com.android.internal.telephony.cdma.CDMAPhone: java.lang.String getSubscriberId()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhoneBase: java.lang.String getVoiceMailAlphaTag()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhone: java.lang.String getPhoneName()");
		sourceApiList.add("com.android.internal.telephony.gsm.GSMPhone: java.lang.String getMsisdn()");
		sourceApiList.add("com.android.internal.telephony.PhoneSubInfoProxy: java.lang.String getIsimImpi()");
		sourceApiList.add("com.android.internal.telephony.PhoneSubInfo: java.lang.String getMsisdn()");
		sourceApiList.add("com.android.internal.telephony.sip.SipPhone: java.lang.String getSubscriberId()");
		sourceApiList.add("com.android.internal.telephony.PhoneSubInfoProxy: java.lang.String getSubscriberId()");
		return sourceApiList;
	}

	public List<String> getSinkApi(){
		List<String> sinkApiList = new ArrayList<String>();
		sinkApiList.add("android.telephony.SmsManager: void sendTextMessage(java.lang.String,java.lang.String,java.lang.String,android.app.PendingIntent,android.app.PendingIntent;)");
		
		sinkApiList.add("android.telephony.SmsManager: void sendTextMessage(java.lang.String,java.lang.String,java.lang.String,android.app.PendingIntent,android.app.PendingIntent)");
		sinkApiList.add("com.android.internal.telephony.gsm.GsmSMSDispatcher: void sendSms(com.android.internal.telephony.SMSDispatcher$SmsTracker)");
		sinkApiList.add("com.google.android.mms.util.PduCache: boolean put(java.lang.Object,java.lang.Object)");
		sinkApiList.add("com.google.android.mms.pdu.RetrieveConf: void setReadReport(int)");
		sinkApiList.add("com.google.android.mms.pdu.RetrieveConf: void setReadReport(int)");
		sinkApiList.add("com.android.mms.transaction.SmsMessageSender: boolean sendMessage(long)");
		sinkApiList.add("com.android.email.Controller: void sendMessage(com.android.emailcommon.provider.EmailContent$Message)");
		sinkApiList.add("com.android.emailcommon.service.EmailServiceProxy: void sendMeetingResponse(long,int)");
		sinkApiList.add("com.android.emailcommon.service.EmailServiceProxy: void setLogging(int)");
		sinkApiList.add("com.android.emailcommon.service.EmailServiceProxy: void sendMail(long)");
		sinkApiList.add("com.android.email.service.EmailServiceUtils$NullEmailService: void sendMeetingResponse(long,int)");
		sinkApiList.add("com.android.email.MessagingListener: void sendPendingMessagesCompleted(long)");
		return sinkApiList;
	}
	public String checkInvokeApi(String invoke,List<String> apiOrder){
		List<String> sinkApi = this.getSinkApi();
		List<String> sourceApi = this.getSourceApi();
		
//				String temp = ((invoke.split("inter:"))[1].split(", L"))[1];
				String temp1=invoke.split("inter:")[1];
				String temp=temp1.substring(temp1.indexOf(" L")+2);
//				System.out.println(temp);
				String className = (temp.split(";->"))[0];
				className = className.replaceAll("/", ".");
				String n  = temp.split(";->")[1];
				String methodName = (temp.split(";->")[1].split("\\("))[0];
				String returnType =((((temp.split(";->")[1].split("\\("))[1]).split("\\)")[1]).split(";"))[0].trim().replaceAll("L", "").replaceAll("/", ".");
				if(returnType.endsWith("V")){
					returnType= "void";
				}
				String attribute = (((temp.split(";->")[1].split("\\("))[1]).split("\\)")[0]).replaceAll("; ", ",").replaceAll("/", ".").replaceAll("L", "").replaceAll(";", "");
				String api = className+": "+returnType+" "+methodName+"("+attribute+")";
				
				
				for(String s:sinkApi){
					if (s.equals(api)) {
						apiOrder.add("sinkAPI");
	//					System.out.println(temp+"is"+"sinkAPI");
						result.append(temp+"is"+"sinkAPI\n");
					}
				}
				for(String s:sourceApi){
					if (s.equals(api)) {
						apiOrder.add("sourceAPI");
		//				System.out.println(temp+"is"+"sourceAPI");
						result.append(temp+"is"+"sourceAPI\n");
					}
				}
				
			
			
		return "";
	} 
	public void analysis(){
        try {
        // read file content from file
        StringBuffer sb= new StringBuffer("");
       
        FileReader reader = new FileReader(filePath);
        BufferedReader br = new BufferedReader(reader);
       
        String str = null;
       String methodName = "";
       List<String> apiOrder = new ArrayList<String>();
        while((str = br.readLine()) != null) {
        	 if(str.contains("Method:")){
        		 if(!methodName.equals("")&&this.getSourceSinkOrderMap().get(methodName).size()==0){
        			 this.getSourceSinkOrderMap().remove(methodName);
        		 }
        		 methodName = str.split("Method:")[1];
        		 apiOrder = new ArrayList<String>();
        		 this.getSourceSinkOrderMap().put(methodName, apiOrder);
        	 }
        	 if(str.contains("inter:")){
        		 this.checkInvokeApi(str,apiOrder);
        		 String[] invoke=str.split("inter:");
        		for (int i = 1; i < invoke.length; i++) {
        			this.checkInvokeApi("inter:"+invoke[i],apiOrder);
				} 	 
        	 }
        	
              sb.append(str+"/n");
//              System.out.println(str);
        }
        br.close();
        reader.close();
	  }
	  catch(FileNotFoundException e) {
	              e.printStackTrace();
	        }
	        catch(IOException e) {
	              e.printStackTrace();
	        }

	}
	public String checkMouliciousInEachMethod(){
		
	   String resultString = "safe";
	   Iterator<String> iterator=this.getSourceSinkOrderMap().keySet().iterator();
       while(iterator.hasNext()){
              String name=(String)iterator.next();
              List<String> values=this.getSourceSinkOrderMap().get(name);
              String source = "";
              for(String s : values){
        //    	  System.out.println(name+":"+s);
            	  result.append(name+":"+s+"\n");
            	  if(s.equals("sourceAPI")){
            		  source = "sourceFirst";
            	  }else if(s.equals("sinkAPI")&&source.equals("sourceFirst")){
            		  resultString = "unsafe";
            	  }
              }
       }
	   return resultString;
	}
	public String checkEveryScenario(String[] scenario){
		List<String> list = new ArrayList<String>();
		if(this.checkMouliciousInEachMethod().equals("safe")){
			for(String s :scenario){
				if (!s.equals("*")) {
					String type = this.findTaintType(s);
					if(!type.equals("None")){
						list.add(type);
					}
				}else{
					for(String callback : this.getCallBackFunctions()){
						String type =this.findTaintType(callback);
						if(!type.equals("None")){
							list.add(type);
						}
					}
				}
			}
			for(String s :list){
	//			System.out.println("------------------------"+s);
				result.append("------------------------"+s+"\n");
			}
			
			String resultString = "safe";
			String record1 = "";
			String record2 = "";
            for(String s : list){
            	
            	if (s.equals("onlySource")) {
					record1 = "onlySource";
				}else if(s.equals("onlySink")&&record1.equals("onlySource")||s.equals("Both")&&record1.equals("onlySource")){
					resultString= "unsafe";
				}
            	
          	  	if(s.equals("Both")&&!record2.equals("Both")){
          	  		record2 = "Both";
          	  	}else if(s.equals("onlySink")&&record2.equals("Both")||s.equals("Both")&&record2.equals("Both")){
          	  		resultString= "unsafe";
          	  	}
            }
			
			return resultString;
		}else{
			return "unsafe";
		}
	}
	public String findTaintType(String callBackFunction){
		List<String> list = new ArrayList<String>();
		String taint = "";
		if (this.getSourceSinkOrderMap().keySet().contains(callBackFunction)) {
			list =this.getSourceSinkOrderMap().get(callBackFunction);
			if(list.contains("sourceAPI")){
				taint ="onlySource";
			}else if(list.contains("sinkAPI")){
				taint="onlySink";
			}
			if(list.contains("sinkAPI")&&list.contains("sourceAPI")){
				taint="Both";
			}
			
		}else{
			taint="None";
		}
		
		return taint;
	}
	public boolean ifCallBackFunction(String callback){
		boolean res = false;
		String[] callbackFunctions = this.getCallBackFunctions();
		for(String s :callbackFunctions){
			if(s.equals(callback)){
				res = true ;
			}
		}
		return res;
	}
	
	public Map<String,List<String>> getSourceSinkOrderMap() {
		return sourceSinkOrderMap;
	}

	public void setSourceSinkOrderMap(Map<String,List<String>> sourceSinkOrderMap) {
		this.sourceSinkOrderMap = sourceSinkOrderMap;
	}

	public String[] getScenario_1() {
		return Scenario_1;
	}

	public void setScenario_1(String[] scenario_1) {
		Scenario_1 = scenario_1;
	}

	public String[] getScenario_2() {
		return Scenario_2;
	}

	public void setScenario_2(String[] scenario_2) {
		Scenario_2 = scenario_2;
	}

	public String[] getScenario_4() {
		return Scenario_4;
	}

	public void setScenario_4(String[] scenario_4) {
		Scenario_4 = scenario_4;
	}

	public String[] getScenario_3() {
		return Scenario_3;
	}

	public void setScenario_3(String[] scenario_3) {
		Scenario_3 = scenario_3;
	}

	public String[] getScenario_5() {
		return Scenario_5;
	}

	public void setScenario_5(String[] scenario_5) {
		Scenario_5 = scenario_5;
	}

	public String[] getCallBackFunctions() {
		return callBackFunctions;
	}

	public void setCallBackFunctions(String[] callBackFunctions) {
		this.callBackFunctions = callBackFunctions;
	}
	
	public StringBuffer getResult(){
        result.append("======"+checkEveryScenario(getScenario_1())+"\n"+"======"+checkEveryScenario(getScenario_2())+"\n"
    	        +"======"+checkEveryScenario(getScenario_3())+"\n" +"======"+checkEveryScenario(getScenario_4()) +"\n"
    	        +"======"+checkEveryScenario(getScenario_5()));
		return result;
	}
	
//	public static void main(String[] args) {
//		
//		TaintAnalyzer ta = new TaintAnalyzer();
//		ta.analysis();
//		System.out.println(ta.result);
//		System.out.println("======"+ta.checkEveryScenario(ta.getScenario_1()));
//		System.out.println("======"+ta.checkEveryScenario(ta.getScenario_2()));
//		System.out.println("======"+ta.checkEveryScenario(ta.getScenario_3()));
//		System.out.println("======"+ta.checkEveryScenario(ta.getScenario_4()));
//		System.out.println("======"+ta.checkEveryScenario(ta.getScenario_5()));
//	}
}
