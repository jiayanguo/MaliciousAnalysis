package com.uta.dexteroid.cfg;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.uta.dexteroid.graph.Vertex;

public class TaintAnalysisFile {
	private String dalvikPath;
	private String resultPath=AndroGuard.OUTPUTFP+"IepCFGgeneratorResult.txt";
	private Map bbOrderMap;
	public TaintAnalysisFile(String fileName, Map methodMap){
		//this.dalvikPath=AndroGuard.OUTPUTFP+fileName;
		this.dalvikPath=fileName;
		this.bbOrderMap=methodMap;
	}
	
	public void writeFile(){
		try{
			//Read the dalvik byte code file
			FileInputStream fis = new FileInputStream(dalvikPath);
			FileWriter  fWriter=new FileWriter(new File(resultPath));
			
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fis);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			BufferedWriter bWriter=new BufferedWriter(fWriter);
			
			//line in file
			String strLine;
			
			//get package path
			strLine = br.readLine();
			String []methodPath=strLine.split(";");
			String []path=methodPath[0].split("/");
			String packagePath ="";
			for(int i=0; i<path.length-1; i++){
				packagePath+=path[i]+"/";
			}
			//System.out.println (packagePath);
			int packagePathLength=packagePath.length();
			
			
			//define method, class and bb 
			String className="";
			String methodName="";
			boolean flag=false;
			String methodNode=null;
			String[] bb=null;					
			int num=-1;
			//Read File Line By Line
			do {
				if(strLine.substring(0,(packagePathLength>strLine.length())? strLine.length() : packagePathLength).equals(packagePath)){
					
					flag=false;
					methodPath=strLine.split(" ");
					path=methodPath[0].split("/");
					if(!className.equals(path[path.length-1].split(";")[0])){
						
						className=path[path.length-1].split(";")[0];
					}
					methodName=methodPath[1];
					
					methodNode=className+"/"+methodName;
					if(bbOrderMap.containsKey(methodNode)){
						flag=true;
						
						if (bb!=null) {
							
							String str="";
							for (int i = 0; i < bb.length; i++) {
								if (i==bb.length-1) {
									if (bb[i]=="") {
										str+=i;
									}else{
										str+=i+" inter:"+bb[i];
									}
									
								}
								else if (bb[i]=="") {
									str+=i+System.getProperty("line.separator");
								}else {
									str+=i+" inter:"+bb[i]+System.getProperty("line.separator");
								}	
							}
							bWriter.write(str);
							bWriter.newLine();
							num=-1;
						}
						bb=new String[((List) bbOrderMap.get(methodNode)).size()];
						if (bb!=null) {
							for (int i = 0; i < bb.length; i++) {
								bb[i]="";
							}
						}
						bWriter.write("Class:"+className);
						bWriter.newLine();
						bWriter.write("Method:"+methodName);
						bWriter.newLine();
						
//						bWriter.write(methodNode);
//						bWriter.newLine();
					}
					
				}
				else if(flag){
				
					if(strLine.indexOf("NEXT")>=0 || strLine.indexOf("PREV")>=0 ){
						
						String bbNum=strLine.substring(strLine.indexOf("BB@"),strLine.indexOf(" "));
						List<Vertex> bbList=(List) bbOrderMap.get(methodNode);
						
						for (int i = 0; i < bbList.size(); i++) {
							if(bbNum.equals(bbList.get(i).getName())){
								num=i;
								break;
							}
						}

					}
					else if(strLine.indexOf("invoke-")>=0){
						//if (strLine.indexOf("Ljava")==-1) {
							if (bb[num]=="") {
								bb[num]+=strLine.substring(strLine.indexOf("invoke-"));
							}else{
								bb[num]+=" inter:"+strLine.substring(strLine.indexOf("invoke-"));
							}

						//}
					}
				}
			}while ((strLine = br.readLine()) != null); 
			
			if (bb!=null) {
				
				String str="";
				for (int i = 0; i < bb.length; i++) {
					if (i==bb.length-1) {
						if (bb[i]=="") {
							str+=i;
						}else{
							str+=i+" inter:"+bb[i];
						}
						
					}
					else if (bb[i]=="") {
						str+=i+System.getProperty("line.separator");
					}else {
						str+=i+" inter:"+bb[i]+System.getProperty("line.separator");
					}	
				}
				bWriter.write(str);
				bWriter.newLine();
			
			}
			bWriter.flush();
			//Close the input stream
			in.close();
			fWriter.close();
		}catch (Exception e){//Catch exception if any
		    System.err.println("Error: " + e.getMessage());
		}
	}
	
//	public static void main(String[] args){
//		CFGGenerator cfg=new CFGGenerator("TestMaliciousApp.apk");
//		TaintAnalysisFile file=new TaintAnalysisFile(AndroGuard.OUTPUTFP+"TestMaliciousApp.apk.txt",cfg.bbOrderMap );
//		file.writeFile();
//	}
	
}
