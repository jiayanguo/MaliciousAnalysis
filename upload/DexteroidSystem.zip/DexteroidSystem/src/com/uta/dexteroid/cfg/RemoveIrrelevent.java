package com.uta.dexteroid.cfg;

import java.util.ArrayList;
import java.util.List;

public class RemoveIrrelevent implements CFGCommand{
	List<String> irrelevent;
	ArrayList<String> methodList;
	public  RemoveIrrelevent(ArrayList list) {
		// TODO Auto-generated constructor stub
		irrelevent=new ArrayList<String>();
		irrelevent.add("BuildConfig");
		irrelevent.add("R$attr");
		irrelevent.add("R$drawable");
		irrelevent.add("R$id");
		irrelevent.add("R$layout");
		irrelevent.add("R$menu");
		irrelevent.add("R$string");
		irrelevent.add("R$style");
		irrelevent.add("R");
		
		methodList=list;
	}

	@Override
	public void excute() {
		// TODO Auto-generated method stub
		removeIrrelevent();
	}
	
	private void removeIrrelevent() {
		// TODO Auto-generated method stub
		for (int i=0; i<methodList.size();i++){
			String cmName=methodList.get(i);
			String className=cmName.split("/")[0];
			if (irrelevent.indexOf(className)>=0) {
				methodList.remove(cmName);
				i--;
				//System.out.println(cmName);
			}
		}
	}

}
