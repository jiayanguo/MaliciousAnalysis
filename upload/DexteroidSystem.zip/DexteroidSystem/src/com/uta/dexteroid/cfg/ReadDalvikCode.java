package com.uta.dexteroid.cfg;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ReadDalvikCode {
	public   Map<String, String> methodMap=new IdentityHashMap();
	public   ArrayList<String> methodList=new ArrayList();
	public   List<String> methodInvoke=new ArrayList<String>();
	
	public ReadDalvikCode(String path){  //path means dalvik byte code file path
		this.init(path);
	}
	
	private void init(String dalvikPath){
		try{
			//Read the dalvik byte code file
			FileInputStream fis = new FileInputStream(dalvikPath);
			
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fis);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			//line in file
			String strLine;
			
			//get package path
			strLine = br.readLine();
			String []methodPath=strLine.split(";");
			String []path=methodPath[0].split("/");
			String packagePath ="";
			for(int i=0; i<path.length-1; i++){
				packagePath+=path[i]+"/";
			}
			//System.out.println (packagePath);
			int packagePathLength=packagePath.length();
			
			
			//define method, class and bb 
			String className="";
			int classNameLength=className.length();
			String methodName="";
			int methodNamelength=methodName.length();
			String bbName="";

			
			//Read File Line By Line
			do {
				if(strLine.substring(0,(packagePathLength>strLine.length())? strLine.length() : packagePathLength).equals(packagePath)){
					methodPath=strLine.split(" ");
					path=methodPath[0].split("/");
					if(!className.equals(path[path.length-1].split(";")[0])){
						
						className=path[path.length-1].split(";")[0];
					}
					methodName=methodPath[1];
					
					String methodNode=className+"/"+methodName;
					methodList.add(methodNode);
					
				}
				else if(strLine.indexOf("NEXT")>=0 || strLine.indexOf("PREV")>=0 ){
					
					String key=className+"/"+methodName;
					String value=strLine;
					
					methodMap.put(key, value);
		
				}
				else if(strLine.indexOf("invoke-")>=0){
					int index;
					if ((index=strLine.indexOf(packagePath))>=0) {
						String s1=strLine.substring(index+packagePathLength, strLine.indexOf("->")-1);
						String s2=strLine.substring(strLine.indexOf("->")+2,strLine.indexOf("("));
						String cm=s1+"/"+s2;
						//System.out.println(cm);
						
						String methodNode=className+"/"+methodName;
						String methodOrder=methodNode+"//"+cm;
						methodInvoke.add(methodOrder);
						//System.out.println(methodOrder);
					}
				}
			}while ((strLine = br.readLine()) != null); 
			//Close the input stream
			in.close();
		}catch (Exception e){//Catch exception if any
		    System.err.println("Error: " + e.getMessage());
		}
		
	}
		
}
