package com.uta.dexteroid.cfg;

import java.util.List;
import java.util.Map;

import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graphOperation.ConvertToAcyclicGraphStrategy;


/**
 * This class can detect Loop in the graph, and delete back edge of the graph.
 * And the same time we use traversal algorithms to show the visit order. 
 */
public class LoopDetector implements CFGCommand{
	public Graph graph;
	public LoopDetector(Graph graph){
		
		this.graph=graph;
	}
	@Override
	public void excute() {
		// TODO Auto-generated method stub
		new ConvertToAcyclicGraphStrategy(graph).execute();
	}
	
}
