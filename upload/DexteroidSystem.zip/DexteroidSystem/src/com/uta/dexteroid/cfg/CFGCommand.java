package com.uta.dexteroid.cfg;

public interface CFGCommand {

	void excute();
}
