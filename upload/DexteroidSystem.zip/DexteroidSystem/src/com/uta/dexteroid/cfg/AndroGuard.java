package com.uta.dexteroid.cfg;
import java.io.*;
 
public class AndroGuard {
 
	/**
	 * This class used for calling python sript in androguard (cfgAndroFile) to get dalvik byte code
	 * The input is tested apk file
	 * The output is dalvik byte code, we store it in an txt file.
	 */
	
	private final static String COMMAND="python Androguard/cfgAndroFile.py";  //call androguard
	private final static String INPUTFP=" -i D:\\MaliciousAPPAnal\\";   //input apk folder
	//public final static String OUTPUTFP="MaliciousAppsResults/";    //output folder for dalvik byte code
	
	public final static String OUTPUTFP="D:\\DalResult\\";    //output folder for dalvik byte code
	
	private static AndroGuard uniqueInstance;
	private AndroGuard(){}
	public static AndroGuard getInstance(){
		if(uniqueInstance==null){
			uniqueInstance=new AndroGuard();
		}
		return uniqueInstance;
	}
	
	public static String getDalvikByteCode(String fileName){
		// set up the command and parameter
		String outputFilePath=OUTPUTFP+fileName+".txt";
		String cmd=COMMAND+INPUTFP+fileName+" -o "+outputFilePath;
		
		
		// create runtime to execute external command python script
		Runtime rt = Runtime.getRuntime();
		try {
			Process pr = rt.exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return outputFilePath;
		
	}
}

