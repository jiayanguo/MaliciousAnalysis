package com.uta.dexteroid.cfg;

import java.util.List;

import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graphOperation.RPOTraversalGraphStrategy;

public class BBVisitOrder implements CFGCommand{
	public Graph graph;
	public List visitorder;
	public BBVisitOrder(Graph graph){
		this.graph=graph;
	}
	@Override
	public void excute() {
		// TODO Auto-generated method stub
		RPOTraversalGraphStrategy dfs=new RPOTraversalGraphStrategy(graph);
		dfs.execute();
		visitorder=dfs.traversalOrderList;
	}

}
