package com.uta.dexteroid.cfg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AnalysisBBInMethod {
	//this list used for store all bb information, and we use prefix "c/" to distinguish current bb, 
	//and prefix "n/" to distinguish successor bb, and prefix "p/" to distinguish precursor bb.
	private  List<String> bbList=new ArrayList();	
		
	//this list used for store all the vertex in the graph
	public  List<String> vertexList=new ArrayList();	   
	
	//this map used for store the edge in the graph
	public  Map<String,Integer> edgeMap=new IdentityHashMap();
	
	public AnalysisBBInMethod(Map map, String methodName){  //here methodName should be "className/methodName"; so it can be find in map
		getAllBbInfo(map,methodName);  
		constructGraph(bbList);
	}

	//this function used for get all bb information in one method
	private  void getAllBbInfo(Map<String, String> methodMap,String key){
		
		//search map
		Set set= methodMap.entrySet();   
		Iterator  iterator  =  set.iterator(); 
		
		while (iterator.hasNext())   
		{
			Map.Entry mapentry = (Map.Entry)iterator.next();   
			String method=(String)mapentry.getKey(); 
			if(method.equals(key)){
				String bb=(String)mapentry.getValue();
				//System.out.println(bb);
				String methodName=key.split("/")[1];
				int bbBegin=bb.indexOf(methodName);
				int nt=bb.indexOf("NEXT");
				int pre=bb.indexOf("PREV");
				
				String bbName=bb.substring(bbBegin,nt-2);
				//System.out.println(bbName);
				
				String bbNum=bbName.substring(bbName.indexOf("BB@"),bbName.indexOf(" "));
				String listNode="c/"+bbNum;
				bbList.add(listNode);
				
				//System.out.println("c    "+bbNum);
				
				String []nextArr=bb.substring(nt,pre-4).split("=");
				String []prevArr=bb.substring(pre,bb.length()-2).split("=");
									
				
				if(nextArr[1].indexOf("BB@")>=0){
					String []succ=nextArr[1].split(" ");
					
					for(int i=1; i<succ.length; i++){
						bbNum=succ[i].substring(succ[i].indexOf("BB@"),succ[i].length());
						listNode="n/"+bbNum;
						bbList.add(listNode);
						//System.out.println("N    "+bbNum);
					}
				}
				
				if(prevArr[1].indexOf("BB@")>=0){
					String []prec=prevArr[1].split(", ");
					
					for(int i=0; i<prec.length;i++){
						bbNum=prec[i].substring(prec[i].indexOf("BB@"),prec[i].length());
						listNode="p/"+bbNum;
						bbList.add(listNode);
						//System.out.println("p    "+bbNum);
					}
				}
			}

		} 
	}

	//this function used for store  all tree information for constructing one graph, include vertex and edges.
	private  void constructGraph(List list){
		String cBb="";
		int cBbIndex=-1;
		String nBb="";
		int nBbIndex=-1;
		String pBb="";
		int pBbIndex=-1;
		
		for (int i=0; i<list.size();i++){
			String []bb=((String) list.get(i)).split("/");
			if(bb[0].equals("c")){
				vertexList.add(bb[1]);
				//System.out.println(bb[1]);
			}
		}
		
		int index=vertexList.indexOf("BB@0x0");
		if(index>0){
			String node=vertexList.get(0);
			vertexList.set(0, "BB@0x0");
			vertexList.set(index, node);
		}
		
		for (int i=0; i<list.size();i++){
			String []bb=((String) list.get(i)).split("/");
			if(bb[0].equals("c")){
				cBb=bb[1];
				cBbIndex=vertexList.indexOf(cBb);
				//System.out.println(cBbIndex);
			}
			
			
			//find successor
			else if(bb[0].equals("n")){
				nBb=bb[1];
				nBbIndex=vertexList.indexOf(nBb);
				edgeMap.put(String.valueOf(cBbIndex),nBbIndex);
				//System.out.println("n"+nBbIndex);
			}
			
			//find  precursor
//				else if(bb[0].equals("p")){
//					pBb=bb[1];
//					pBbIndex=vertexList.indexOf(pBb);
//					edgeMap.put(String.valueOf(pBbIndex),cBbIndex);
//					System.out.println("p"+pBbIndex);
//				}
		}				  
	}
	
}
