package com.uta.dexteroid.cfg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.uta.dexteroid.graph.DirectedGraph;
import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graphOperation.RPOTraversalGraphStrategy;


public class CFGGenerator {
	public HashMap<String, List> bbOrderMap=new HashMap<>();
	
	public CFGGenerator(String apk){
		String dalvikCodePath=AndroGuard.OUTPUTFP+apk+".txt";
		
		//first step, call PythonCaller get dalvik byte code
		AndroGuard pc=AndroGuard.getInstance();		
		String result=pc.getDalvikByteCode(apk);
		System.out.println(result);	
		
		//second step, read dalvik byte code, and construct graph
		ReadDalvikCode rdc=new ReadDalvikCode(dalvikCodePath);
		RemoveIrrelevent irrelevent=new RemoveIrrelevent(rdc.methodList);
		irrelevent.excute();
		//rdc.methodList=irrelevent.methodList;
		
		for(int i=0; i<rdc.methodList.size(); i++){
			AnalysisBBInMethod abm=new AnalysisBBInMethod(rdc.methodMap, rdc.methodList.get(i));
			
			System.out.println(rdc.methodList.get(i));
			List<String> vertexList=abm.vertexList;  //this list used for store node in graph
			System.out.println(vertexList);
			Map<String,Integer> edgeMap=abm.edgeMap;  //this Map use for store edges in graph
			
			//construct graph
			Graph methodGraph=new DirectedGraph();
			//set all vertex of graph
			for(int j=0; j<vertexList.size();j++){
				String node=(String) vertexList.get(j);
				methodGraph.addVertex(node);
			}
			
			
			//set all edges of graph
			Set set= edgeMap.entrySet();   
			Iterator  iterator  =  set.iterator();
			while (iterator.hasNext())   
			{
				Map.Entry mapentry = (Map.Entry)iterator.next();  
				int v1= Integer.parseInt((String)mapentry.getKey()); 
				int v2=(int)mapentry.getValue();
				methodGraph.addEge(v1, v2);
				System.out.println(v1+"  ---->   "+v2);
			}
			
			//detect loop and remove back edge.
			LoopDetector loop=new LoopDetector(methodGraph);
			loop.excute();
			
			//bb visit order 
			BBVisitOrder bbVisitOrder=new BBVisitOrder(methodGraph);
			bbVisitOrder.excute();
			bbOrderMap.put(rdc.methodList.get(i), bbVisitOrder.visitorder);

		}	
		
		//IeP CFG
		IePCFG ipee=new IePCFG(rdc.methodList, rdc.methodInvoke);
		ipee.excute();
		for (int i = 0; i < ipee.graph.vertexList.size(); i++) {
			System.out.print(ipee.graph.vertexList.get(i).getName()+"   ");
		}
		
		//generate taint analysis file
		TaintAnalysisFile file=new TaintAnalysisFile(dalvikCodePath,bbOrderMap );
		file.writeFile();
	
	}
	
//	public static void main(String args[]){
//		CFGGenerator cfg=new CFGGenerator("TestMaliciousApp.apk");
//	}
	
}
