package com.uta.dexteroid.cfg;

import java.util.List;

import com.uta.dexteroid.graph.DirectedGraph;
import com.uta.dexteroid.graph.Graph;
import com.uta.dexteroid.graphOperation.RPOTraversalGraphStrategy;

public class IePCFG implements CFGCommand{
	public List<String> verteList;
	public List<String> methodOrder;
	public Graph graph;
	public IePCFG(List<String> list,List methodOrder){
		verteList=list;
		this.methodOrder=methodOrder;
		graph=new DirectedGraph();
		for (int i = 0; i < verteList.size(); i++) {
			graph.addVertex((String) verteList.get(i));
		}
	}
	
	public void findMethodOrder(){
		
		//System.out.println(verteList);
		for (int i = 0; i < methodOrder.size(); i++) {
			String methodName[]=methodOrder.get(i).split("//");
			//System.out.println(methodName[0]+"  "+methodName[1]);
			if (verteList.indexOf(methodName[1])>=0) {
				//System.out.println("---------------");
				graph.addEge(methodName[0], methodName[1]);
			}
		}
	}
	
	public void RemoveNoEdgeVertex(){
		//System.out.println(graph.getVertexQuan());
		int flag=0;  //find if the vertex exist any edges.
		for (int i = 0; i < graph.getVertexQuan(); i++) {
			for (int j = 0; j < graph.getVertexQuan(); j++) {
				if(graph.edges.adjMatrix[i][j]==1 ||graph.edges.adjMatrix[j][i]==1){
					flag=1;
				}
			}
			if(flag==0 &&i>=0){
				//System.out.println("remove vertex "+graph.getVertexByIndex(i).getName());
				graph.removeVertex(graph.getVertexByIndex(i).getName());
				i--;
			}
			flag=0;			
		}
		//System.out.println(graph.getVertexQuan());	
	}
	
//	public static void main(String[] args){
//		ReadDalvikCode rdc=new ReadDalvikCode("D:\\DalResult\\TestMaliciousApp.apk.txt");
//		RemoveIrrelevent irrelevent=new RemoveIrrelevent(rdc.methodList);
//		irrelevent.excute();
//		IePCFG ipee=new IePCFG(rdc.methodList, rdc.methodInvoke);
//		ipee.excute();
//		System.out.println(ipee.graph.getVertexByIndex(0).getName());
//		new DFSTraversalGraphCommand(ipee.graph).execute();
//		//System.out.println(ipee.graph.getEdgesQuan());
//	}

	@Override
	public void excute() {
		// TODO Auto-generated method stub
		findMethodOrder();
		RemoveNoEdgeVertex();
	}

}
