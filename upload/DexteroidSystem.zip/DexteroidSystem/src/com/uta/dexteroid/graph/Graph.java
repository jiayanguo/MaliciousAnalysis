package com.uta.dexteroid.graph;

import java.util.ArrayList;
import java.util.List;

import com.uta.dexteroid.graphOperation.GraphOperationStrategy;

public abstract class Graph {
	public GraphOperationStrategy strategy;
	public List<Vertex> vertexList;
	public Edges edges;
	public Graph(){
		vertexList=new ArrayList();
		edges=new Edges();
	}
	public void addVertex(String node) {
		vertexList.add(new Vertex(node));
		edges.dilatationMatrix();
	}
	public void addVertex(Vertex vertex){
		vertexList.add(vertex);
		edges.dilatationMatrix();
	}
	public int getVertexIndex(Vertex vertex){
		return vertexList.indexOf(vertex);
	}
	public Vertex getVertexByIndex(int index){
		return vertexList.get(index);
	}
	public abstract void addEge(int begin, int end);
	public abstract void addEge(String begin, String end);

	public void removeVertex(String node) {
		for(int i=0;i<vertexList.size();i++){
			if(vertexList.get(i).getName().equals(node)){
				vertexList.remove(i);
				edges.shrinkMatrix(i);
			}
		}
	}
	public abstract void removeEdge(int begin, int end);
	public abstract void removeEdge(String begin, String end);
	
	public int getVertexQuan() {
		return vertexList.size();
	}
	public abstract int getEdgesQuan();
	
	public Vertex getVertex(int i){
		if(i<vertexList.size()){
			return vertexList.get(i);
		}
		else{
			return null;
		}
	}
	
	public abstract void printAllEdges();
	
	public void setStrategy( GraphOperationStrategy strategy){
		this.strategy=strategy;
	}
	
	public void operation(){
		strategy.execute();
	}
}
