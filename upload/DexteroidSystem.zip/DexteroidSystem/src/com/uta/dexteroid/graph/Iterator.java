package com.uta.dexteroid.graph;

public interface Iterator {
	boolean hasNext();
	Object next();
}
