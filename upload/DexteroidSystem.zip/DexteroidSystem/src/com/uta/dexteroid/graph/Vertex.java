package com.uta.dexteroid.graph;

public class Vertex {
	public static final String BLACK="Black";
	public static final String GRAY="Gray";
	public static final String WHITE="White";
	
	private String name;
	private String color;
	
	public Vertex(String name){
		this.name=name;
		this.color=WHITE;
	}
	
	public void setName(String name){
		this.name=name;
	}
	public String getName(){
		return this.name;
	}
	public void setColor(String color){
		this.color=color;
	}
	public String getColor(){
		return this.color;
	}

}
