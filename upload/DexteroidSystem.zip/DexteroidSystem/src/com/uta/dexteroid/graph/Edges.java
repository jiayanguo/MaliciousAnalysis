package com.uta.dexteroid.graph;

public class Edges {

	public int [][]adjMatrix=null;
	
	public void initMatrix(int size){
		adjMatrix=new int[size][size];
		for(int i=0;i<size;i++)
			for(int j=0;j<size;j++)
				adjMatrix[i][j]=0;
	}
	
	
	//default dilatation 1
	public void dilatationMatrix(){
		if(adjMatrix==null){
			initMatrix(1);
		}
		else {
			int size=adjMatrix[0].length;
			int [][]temp=new int[size+1][size+1];
			for(int i=0;i<size;i++){
				for(int j=0;j<size;j++)
					temp[i][j]=adjMatrix[i][j];
			}
			for(int j=0;j<size+1;j++)
				temp[size][j]=0;
			for(int i=0;i<size;i++)
				temp[i][size]=0;
			adjMatrix=temp;
		}
	}
	
	public void shrinkMatrix(int index){
		if(adjMatrix==null ){
			System.out.println("Matrx erro");
		}
		else if(index>=adjMatrix[0].length){
			System.out.println("Matrx erro");
		}else{
			int size=adjMatrix[0].length;
			int [][]temp=new int[size-1][size-1];
			for(int i=0;i<index;i++){
				for(int j=0;j<index;j++)
					temp[i][j]=adjMatrix[i][j];
			}
			for(int i=index+1;i<size;i++){
				for(int j=index+1;j<size;j++)
					temp[i-1][j-1]=adjMatrix[i][j];
			}
			for(int i=index+1;i<size;i++){
				for(int j=0;j<index;j++)
					temp[i-1][j]=adjMatrix[i][j];
			}
			for(int i=0;i<index;i++){
				for(int j=index+1;j<size;j++)
					temp[i][j-1]=adjMatrix[i][j];
			}
			adjMatrix=temp;
		}
	}
	
	public Iterator createIterator(){
		return new EdgesIterator(adjMatrix);
	}
	
}
