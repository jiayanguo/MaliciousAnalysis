package com.uta.dexteroid.graph;



public class EdgesIterator implements Iterator{
	int[][] matrix;
	int row=0;
	int colum=0;
	public EdgesIterator(int[][] matrix){
		this.matrix=matrix;
	}
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		if(matrix==null){
			return false;
		}
		for(;row<matrix[0].length;row++){
			for(;colum<matrix[0].length;colum++){
				if(matrix[row][colum]==1){
					return true;
				}
			}
			colum=0;
		}
		return false;
	}

	@Override
	public int[] next() {
		// TODO Auto-generated method stub
		int[] edge={row,colum};
		colum++;
		return edge;
	}

}
