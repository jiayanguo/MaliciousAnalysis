package com.uta.dexteroid.graph;

import java.util.ArrayList;
import java.util.List;

public class DirectedGraph extends Graph{
	
	public DirectedGraph(){
		vertexList=new ArrayList<Vertex>();
		edges=new Edges();
	}

	@Override
	public void addEge(int begin, int end) {
		// TODO Auto-generated method stub
		edges.adjMatrix[begin][end]=1;
	}

	@Override
	public void addEge(String begin, String end) {
		// TODO Auto-generated method stub
		int beginIndex=-1;
		int endIndex=-1;
		for (int i=0;i<vertexList.size();i++){
			if(vertexList.get(i).getName().equals(end)){
				endIndex=i;
			}
			if(vertexList.get(i).getName().equals(begin)){
				beginIndex=i;
			}
		}
		if(beginIndex!=-1 && endIndex!=-1){
			edges.adjMatrix[beginIndex][endIndex]=1;
		}
	}
	
	@Override
	public void removeEdge(int begin, int end) {
		// TODO Auto-generated method stub
		edges.adjMatrix[begin][end]=0;
	}

	@Override
	public void removeEdge(String begin, String end) {
		// TODO Auto-generated method stub
		int beginIndex=-1;
		int endIndex=-1;
		for (int i=0;i<vertexList.size();i++){
			if(vertexList.get(i).getName().equals(end)){
				endIndex=i;
			}
			if(vertexList.get(i).getName().equals(begin)){
				beginIndex=i;
			}
		}
		if(beginIndex!=-1 && endIndex!=-1){
			edges.adjMatrix[beginIndex][endIndex]=0;
		}
	}
		
	@Override
	public int getEdgesQuan() {
		// TODO Auto-generated method stub
		if(edges.adjMatrix==null){
			return 0;
		}
		else{
			int count=0;
			for(int i=0;i<edges.adjMatrix[0].length;i++){
				for(int j=0;j<edges.adjMatrix[0].length;j++){
					if(edges.adjMatrix[i][j]==1){
						count++;
					}
				}
			}
			return count;
		}
	}

	@Override
	public void printAllEdges() {
		// TODO Auto-generated method stub
		Iterator iterator=edges.createIterator();
		while(iterator.hasNext()){
			int[] edge=(int[]) iterator.next();
			System.out.println(edge[0]+"--->"+edge[1]);
		}
	}

}
